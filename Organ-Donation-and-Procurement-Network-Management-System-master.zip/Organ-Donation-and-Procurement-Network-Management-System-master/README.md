# Organ Donation and Procurement Network Management System
## DBMS Course Project.
#### Designed a database to efficiently organize data regarding organ transplantation network.
#### Created back-end APIs using FLASK framework.
#### For detailed information regarding the project, please refer DRAFT.pdf
